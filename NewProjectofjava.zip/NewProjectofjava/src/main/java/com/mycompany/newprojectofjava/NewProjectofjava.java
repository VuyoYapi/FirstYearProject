/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.newprojectofjava;

/**
 *
 * @author RC_student_2024
 */
public class NewProjectofjava {

    public static void main(String[] args) {
        // Create an array to hold the months
        String[] months = {"January", "February", "March", "April", "May", "June"};

        // Create a 2D array to hold the number of makeovers for Bathrooms, Kitchens, and Gardens
        int[][] makeovers = {
                {8, 2, 5}, // January
                {7, 4, 5}, // February
                {5, 5, 2}, // March
                {2, 2, 3}, // April
                {7, 7, 9}, // May
                {7, 8, 5}  // June
        };

        // Display the report
        System.out.println("Monthly Home Makeover Report");
        System.out.println("==============================================");
        System.out.println("Month\t\tBathrooms\tKitchens\tGardens\t\tTotal");

        // Iterate over the months and makeovers arrays
        for (int i = 0; i < months.length; i++) {
            int total = makeovers[i][0] + makeovers[i][1] + makeovers[i][2];
            System.out.print(months[i] + "\t\t" + makeovers[i][0] + "\t\t" + makeovers[i][1] + "\t\t" + makeovers[i][2] + "\t\t" + total);

            // Check if the total makeovers for the month are greater than or equal to 15
            if (total >= 15) {
                System.out.print(" ***");
            }

            System.out.println();
        }
        
    }
}
    
