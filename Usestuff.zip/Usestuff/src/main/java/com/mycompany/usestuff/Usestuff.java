/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.usestuff;

/**
 *
 * @author RC_student_2024
 */
public class Usestuff {

    public static void main(String[] args) {
      // Sample data: 15 staff members at the "New York" location
        StaffHiring staffHiring = new StaffHiring(15, "New York");

        // Print the staff hiring report
        staffHiring.printStaffHiring(); 
    }
}
