/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.usestuff;

/**
 *
 * @author RC_student_2024
 */
public abstract class Stuff implements istuff {
    protected int staffNumber;
    protected String staffLocation;
    
    //Constructor
    public Stuff(int staffNumber, String staffLocation){
        this.staffNumber = staffNumber;
        this.staffLocation = staffLocation;
    }
    public int getstaffNumber(){
        return staffNumber;
    }
    public String getstaffLocation(){
        return staffLocation;
    }
    
    public abstract String getStaffHiringProcess();
}
