/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.usestuff;

/**
 *
 * @author RC_student_2024
 */
public interface istuff {
    public int getStaffNumber();
    public String getStaffLocation();
    public String getStaffHiringProcess();
}
