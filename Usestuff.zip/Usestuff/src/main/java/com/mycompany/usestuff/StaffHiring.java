/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.usestuff;

/**
 *
 * @author RC_student_2024
 */
public class StaffHiring extends Stuff {
      // Constructor
    public StaffHiring(int staffNumber, String staffLocation) {
        super(staffNumber, staffLocation);
    }
      // Implement the hiring process
    @Override public String getStaffHiringProcess() {
        if (staffNumber < 20) {
            return "Start the hiring process.";
        } else {
            return "No need to hire more staff.";
        }
    }
    
    // Method to print staff details and hiring decision
    public void printStaffHiring() {
        System.out.println("Staff Location: " + getstaffLocation());
        System.out.println("Number of Staff: " + getstaffNumber());
        System.out.println("Hiring Decision: " + getStaffHiringProcess());
    }

    @Override
    public int getStaffNumber() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String getStaffLocation() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
